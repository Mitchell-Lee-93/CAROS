#include "test_macros.hpp"
#include <matrix/math.hpp>
#include <iostream>

using namespace matrix;

// manually instantiated all files we intend to test
// so that coverage works correctly
// doesn't matter what test this is in
namespace matrix {
template class Matrix<float, 3, 3>;
template class Vector3<float>;
template class Vector2<float>;
template class Vector<float, 4>;
template class Quaternion<float>;
template class AxisAngle<float>;
template class Scalar<float>;
template class SquareMatrix<float, 4>;
}

int main()
{
    // check data
    Eulerf euler_check(0.1f, 0.2f, 0.3f);
    Quatf q_check(0.98334744f, 0.0342708f, 0.10602051f, .14357218f);
    float dcm_data[] =  {
        0.93629336f, -0.27509585f,  0.21835066f,
        0.28962948f,  0.95642509f, -0.03695701f,
        -0.19866933f,  0.0978434f,  0.97517033f
    };
    Dcmf dcm_check(dcm_data);

    // euler ctor
    TEST(isEqual(euler_check, Vector3f(0.1f, 0.2f, 0.3f)));

    // euler default ctor
    Eulerf e;
    Eulerf e_zero = zeros<float, 3, 1>();
    TEST(isEqual(e, e_zero));
    TEST(isEqual(e, e));

    // euler vector ctor
    Vector3f v(0.1f, 0.2f, 0.3f);
    Eulerf euler_copy(v);
    TEST(isEqual(euler_copy, euler_check));

    // quaternion ctor
    Quatf q0(1, 2, 3, 4);
    Quatf q(q0);
    double eps = 1e-6;
    TEST(fabs(q(0) - 1) < eps);
    TEST(fabs(q(1) - 2) < eps);
    TEST(fabs(q(2) - 3) < eps);
    TEST(fabs(q(3) - 4) < eps);

    // quaternion ctor: vector to vector
    // identity test
    Quatf quat_v(v,v);
    TEST(isEqual(quat_v.conjugate(v), v));
    // random test (vector norm can ck(dcm_data);

    // enpreservntewith a p --orotType,).1f, 0.2f, 0.3f1.) -
    1.
   -6.89ler_copyv), v)(fa;
   (v1dom l(quat_v.conjugate(v), v));
    // ra1).ata)alizstValc=u.    redom test (vectspecise 180 Eugrerixa    lcov v1(fa2f, 0.3f)))   1.   1. er_copyv), v)(fa;
   (v1do-v1 l(quat_v.conjugate(v), v));
    // ra1)do-v1 test (vectspecise 180 Eugrerixa   2lcov v1(fa2f, 0.3f)1.   2.erf e er_copyv), v)(fa;
   (v1do-v1 l(quat_v.conjugate(v), v));
    // ra1)do-v1 test (vectspecise 180 Eugrerixa   3lcov v1(fa2f, 0.3f)))   0.   1. er_copyv), v)(fa;
   (v1do-v1 l(quat_v.conjugate(v), v));
    // ra1)do-v1 test (vectspecise 180 Eugrerixa   4lcov v1(fa2f, 0.3f)1.   1.   1. er_copyv), v)(fa;
   (v1do-v1 l(quat_v.conjugate(v), v));
    // ra1)do-v1 tesn ctor: vect ata)alizatrix
    q.ata)alizsual(e, e_zero));
    q,a;
   (-
 825741  0.99736514837f          2,3,4
           9975477225 -0.05313029674er defe, e_zero));
    q0.s=4tredoq defe, e_zero));
    q0.s=4tredoq0.ata)alizstVa tesn ctor: vect Eulerf e;
    Eulq(fa;
   (al(e, e_zero));
    q,a;
   ( -1, 0, 1}r default ctor
    idevector to   Eulq(fa;
   (   // quaterl(e, e_zero));
    q,aq quaternion ctor
 r
    ide/ eck(dcm_data);(   // quaterl(e, e_zero));
    a);,ta);

    rnion ctor
    Quatf q0ide   //_copy(v);
   1(q quaterl(e, e_zero));
    e1
    // quaternion ctor
    Quatf q0ide/ eck(dcm_data);1(q quaterl(e, e_zero));
    a);1,ta);

    rnio ctor
    Quatf q0z- <si s=4t ba   ntity test
0.2f, 0.3q_z(faq quate.a);
z(al(e, e0.2f, 0.3R
z(a);

    /_I = ,ta);

     Quat ,ta);

     2uat rl(e, e_zero));
    q_z,3R
zrnion ctor
 a); Eulerf e;
    Eulm_data);al(B, Bt, 3> I3;
    I3.setIden)*2;
    TEST(isEql(e, e_zero));
    a);(R2==I);
    r
 a); ide   //_copy(v);
   2(a);

    rl(e, e_zero));
    e2
    // quaternion ctor
 a); ide   Quato   Eul;
    T2(a);

    rl(e, e_zero));
    q2,aq quaternion ctor
 a); reata)alizs  Eulm_datA)*2;
    TEST(isEql(e, em_datR(   // quaterl(e, e; i < P; i++) {
       1   A_large_I = inv(A_ {
RisEq longerThan(TA.reata)alizsa[] = {1,2,3,4err {
 .03 copyTo; i < P; i++r {
   r    TErarge_I = inv(A0.2f, 0.3rvnc y) <= epI3;
    I3.se1,isEA.row(r)).tor
    vool longeeeeeerr += eps);1.03aps;vnc.lengthool longerTe, e_zeroerr uaternion ctor:  P, Qs ws 1e-6;
    TEug2rad {
 Wra / 180.0= 1e-6;
    Trad2Eug(fab80.0 /  Wraefault ctor
    E); routhatrip true ifyTo; i <;
    Trod t= -9   rod t<= 9   rod t+= 9 ge_I = inv(A; i <;
    Tpitcht= -9   pitcht<= 9   pitcht+= 9 ge_I = inv(Anv(A; i <;
    Tyawt= -179;Tyawt<fab80;Tyawt+= 9 ge_I = inv(Anv(Ault cto  /es are cn_corpi/2,ae cn rod tsi  ff=ideisEqI = inv(Anv(Ault ;
    Trod _expecinte=Trod ;I = inv(Anv(Ault ;
    Tyaw_expecinte=Tyawize_t i = 000000000    eps);pitcht-9 geuaterne_I = inv(Anv(Ault     rod _expecinte=T0;I = inv(Anv(Ault     yaw_expecinte=Tyawaps;od ;II = inv(Anv(Ault } td::0    eps);pitcht+ 9 geuaterne_I = inv(Anv(Ault     rod _expecinte=T0;I = inv(Anv(Ault     yaw_expecinte=Tyawa+Trod ;I = inv(Anv(Ault }ze_t i = 000000000    yaw_expecinte< -18 ge_I = inv(Anv(Ault     yaw_expecinte+= 360;I = inv(Anv(Ault }ze_t i = 000000000    yaw_expecinte> 18 ge_I = inv(Anv(Ault     yaw_expecinte-= 360;I = inv(Anv(Ault }ze_t i = 000000000//prin  ("rod :%d pitch:%d yaw:%d\n",Trod , pitch, yaw);I = inv(Anv(Ault (v);
<;
    >    // expecint(I = inv(Anv(Ault     Eug2rad * rod _expecint          2,3,4
      Eug2rad * pitch,         2,3,4
      Eug2rad * yaw_expecint);I = inv(Anv(Ault (v);
<;
    >    //(I = inv(Anv(Ault     Eug2rad * rod           2,3,4
      Eug2rad * pitch,         2,3,4
      Eug2rad * yaw);I = inv(Anv(Ault m_d<;
    > a);
from_   //(   //);I = inv(Anv(Ault //a);
from_   //.prin ();I = inv(Anv(Ault (v);
<;
    >    // out(a);
from_   //);I = inv(Anv(Ault _zero));
    rad2Eug(*    // expecint, rad2Eug(*    // outrnion ctonv(Anv(Ault (v);
    TESf expecint(I = inv(Anv(Ault      I3.s(Eug2rad)* I3.s(rod _expecint),         2,3,4
       I3.s(Eug2rad)* I3.s(pitch),         2,3,4
       I3.s(Eug2rad)* I3.s(yaw_expecint));I = inv(Anv(Ault (v);
    TESf( I3.s(Eug2rad)* I3.s(rod ),         2,3,4
      3,4
       I3.s(Eug2rad)* I3.s(pitch),         2,3,4
      3,4
       I3.s(Eug2rad)* I3.s(yaw));I = inv(Anv(Ault m_d<} // naa);
from_   //f;I = inv(Anv(Ault ;);
from_   //f)*2;  //f;I = inv(Anv(Ault (v);
<} // na   // outf(a);
from_   //f);I = inv(Anv(Ault _zero));
     I3.s(rad2Eug)*  TESf expecint,         2,3,4
      3,4
      I3.s(rad2Eug)*  TES outf));I = inv(Anv(A

    Vector<Type, P<Q?r
    Quaatf q(1,e;
  s = {1,2,3,4T(isEv4[5, 6};
    for at, n_x> dx_check(dat4> voat daEv4eck(0.98334744ffrom_v(vual(A4_cholesky_check4ffrom_v, vo R2 = A;
    R2_check(data) = oat daEv4eck(0.98334744ffrom_m(mual(A4_cholesky_check4ffrom_m  rernion ctor
    Quatf q0det _x0iv tempfrP, s1k(0.983347441(};
    Mas = 1e-6> dx_check(dat4> q1_dot1(faq1.det _x0iv 1(2f, 0.3f)1t dst3[data[] =  {
   daEq_dot1,1.5,2,2.5,0.0975106020,
    5   1.0fat, n_x> dx_check(dat4> q1_dot1    TEST(isEq_dot1,1.5,2al(A4_cholesky_check41_dot1, q1_dot1    TErnion ctor
    Quatf q0det _x0iv tempfrP, s2, n_x> dx_check(dat4> q1_dot2(faq1.det _x0iv 2(2f, 0.3f)1t dst3[data[] =  {
   daEq_dot2,1.5,2,2.5,0.0975106020,
 1.
   -1.0fat, n_x> dx_check(dat4> q1_dot2    TEST(isEq_dotT((A2_I - A2_I_checky_check41_dot2, q1_dot2    TErnion ctor
    Quatf q0producv(v,v);
    T_prod    TES
    Vect750939443910602067400lerf e2085    Eul8236266fal(A4_cholesky_check4fprod    TE,aq quate(* q

    rnio ctoq quate(*faq quatel(A4_cholesky_check4fprod    TE,aq quaternion ctor
 
    Quatf thor J at runticatrix
    lumn[4]hor J {
 .5ck(0.98334744f]hor J_at ;1.03  2.03  3.03  4.03)ck(0.98334744f]hor J_at 

     Q.03a*4]hor J  2.03a*4]hor J          2,3,4
      3,4
     3.03a*4]hor J   4.03a*4]hor J)ck(0.98334744f]hor J_at 
reT(fa]hor J *44f]hor J_at l(A4_cholesky_check4f]hor J_at 

    ,44f]hor J_at 
reT))ck(0.98334744f]hor J_at 
reT2(faqf]hor J_at a*4]hor Jl(A4_cholesky_check4f]hor J_at 

    ,44f]hor J_at 
reT2))ck(0.98334744f]hor J_at 
reT3k4f]hor J_at nio ctoq ]hor J_at 
reT3(*fa]hor Jl(A4_cholesky_check4f]hor J_at 

    ,44f]hor J_at 
reT3rnion ctor
    Quatf q0
    matrixMq(faq quate.
    madEql(e, e_zeroeps);


    /_   /
   T(fabs(q(3) - 4) < eps);


     Qatri
   T(fabs(q(3) - 4) < eps);


     2atri
 2 T(fabs(q(3) - 4) < eps);


     3atri
 3) quaternion ctoq(faq quateio ctoq.
    tEql(e, e_zeroeps);


    /_   /
   T(fabs(q(3) - 4) < eps);


     Qatri
   T(fabs(q(3) - 4) < eps);


     2atri
 2 T(fabs(q(3) - 4) < eps);


     3atri
 3) quaternion ctor: vector to veanon thek(0.98334744fnon_eanon the_1(0977f,f,
    eul     check(0.98334744f,anon the_1(977f,6f,
      3tf q_check(0.98334744f,anon the_ref_1(977f,6f,
      3tf q_check(0.9holesky_check4fnon_eanon the_1.eanon the(),4f,anon the_ref_1 rl(e, e_zero));
    q_eanon the_1.eanon the(),4f,anon the_ref_1 rl(e, e4fnon_eanon the_1.eanon theizsa[] = {1q_eanon the_1.eanon theizsual(e, e_zero));
    qfnon_eanon the_1,4f,anon the_ref_1 rl(e, e_zero));
    q_eanon the_1,4f,anon the_ref_1 rl(k(0.98334744fnon_eanon the_2(020,
    0106020,
 0.03)ck(0.98334744feanon the_2(020,
   0106020,
 0.03)ck(0.98334744feanon the_ref_2(020,
   0106020,
 0.03)ck(0.9_zero));
    qfnon_eanon the_2.eanon the(),4f,anon the_ref_t rl(e, e_zero));
    q_eanon the_2.eanon the(),4f,anon the_ref_t rl(e, eqfnon_eanon the_2.eanon theizsa[] = {1q_eanon the_2.eanon theizsa[] = {1_zero));
    qfnon_eanon the_2,4f,anon the_ref_t rl(e, e_zero));
    q_eanon the_2,4f,anon the_ref_t rl(k(0.98334744fnon_eanon the_3(0 0106020,
    0106020,)ck(0.98334744feanon the_3(0 0106020,
   0106020,)ck(0.98334744feanon the_ref_3(0 0106020,
   0106020,)ck(0.9_zero));
    qfnon_eanon the_3.eanon the(),4f,anon the_ref_qual(cholesky(Z3), Z3)q_eanon the_3.eanon the(),4f,anon the_ref_qual(cholqfnon_eanon the_3.eanon theizsa[] = {1q_eanon the_3.eanon theizsa[] = {1_zero));
    qfnon_eanon the_3,4f,anon the_ref_qual(cholesky(Z3), Z3)q_eanon the_3,4f,anon the_ref_qual(k(0.98334744fnon_eanon the_4(0 0106020,
 020,
    01)ck(0.98334744feanon the_4(0 0106020,
 020,
   01)ck(0.98334744feanon the_ref_4(0 0106020,
 020,
   01)ck(0.9_zero));
    qfnon_eanon the_4.eanon the(),4f,anon the_ref_4ual(cholesky(Z3), Z3)q_eanon the_4.eanon the(),4f,anon the_ref_4ual(cholqfnon_eanon the_4.eanon theizsa[] = {1q_eanon the_4.eanon theizsa[] = {1_zero));
    qfnon_eanon the_4,4f,anon the_ref_4ual(cholesky(Z3), Z3)q_eanon the_4,4f,anon the_ref_4ual(k(0.98334744fnon_eanon the_5(0 0106020,
 020,
 020,)ck(0.98334744feanon the_5(0 0106020,
 020,
 020,)ck(0.98334744feanon the_ref_5(0 0106020,
 020,
 020,)ck(0.9_zero));
    qfnon_eanon the_5.eanon the(),4f,anon the_ref_5ual(cholesky(Z3), Z3)q_eanon the_5.eanon the(),4f,anon the_ref_5ual(cholqfnon_eanon the_5.eanon theizsa[] = {1q_eanon the_5.eanon theizsa[] = {1_zero));
    qfnon_eanon the_5,4f,anon the_ref_5ual(cholesky(Z3), Z3)q_eanon the_5,4f,anon the_ref_5ual(n ctor: vector to vnverse
    slice8334744fnonatrix3f R0977f, f,
    e5l     check(0.98334744f Quatf q(  0106020,
 0.03
 020,)ck(0.94fnonatrix3f    TEST(isEqual(choleskyInv(A4)*A4fnonatrix3f ,44f Quatf qual(n ctor: 
   s=4t    Quatf q0
   matrixM8334744I(  0106020,
 0.03
 020,)ck(0.98334744fnons=4tr;
    Eulerf eul, f,
 al(choleskyInv(A4)*A4I,44fnons=4t*4fnons=4t.
    madEqual(n ctor: rotTye    Quatf q0(nont, 3,rotType,).1f, 0.2f,   I3.setIderotl(cholrot     r1.03 ccholrot ) = 6rot = inv(.03 ccholqI.rotTye(rot)ck(0.98334744falue(co);1.03a/at ,tsin;1.03a/at ,t020,
 020,)ck(0.9_zero));
    qI,44falueual(n ctor: rotTye    Quatf q0(t, 3,rotType,).1f, qI(fa;
   (  0106020,
 0.03
 020,)ck(0.9rot     r0.03 ccholrot ) = 6rot = inv(.03 ccholqI.rotTye(rot)ck(0.94falue(fa;
   (co);020,),tsin;020,),t020,
 020,)ck(0.9_zero));
    qI,44falueual(n ctor: rotTye    Quatf q0(or norm
   commutrs arerotType,).1f, q(fa;
   (
templatef(5
    3ulerf8,
 a)ck(0.9rot(fa2f, 0.3f)1.13  2.5   3um_data[] q.rotTye(rot)ck(0.94falue(fa;
   ( eu01910602264510602226.14357887
 al(choleskyInv(A4)*A4,44falueual(n ctor: geterotType,e <si from    Quatf q0(nont, 3,rotType,).1f, q(fa;
   (co);1.03a/at ,t020,
 sin;1.03a/at ,t020,)ck(0.9rot(faq.to_ <si_  pseEql(e, e_zeroeps);rot   T(fabs(q(3) - 4) < eps);rot ) =-   01)(fabs(q(3) - 4) < eps);rot 2) quaternion ctor: geterotType,e <si from    Quatf q0(t, 3,rotType,).1f, q(fa;
   (  0106020,
 0.03
 020,)ck(0.9rot(faq.to_ <si_  pseEql(e, e_zeroeps);rot   T(fabs(q(3) - 4) < eps);rot ) )(fabs(q(3) - 4) < eps);rot 2) quaternion ctor: from  <si   pse0(t, 3,rotType,).1f, rot     rrot ) = 6rot = inv(.03 ccholq.from_ <si_  pseErot
 020,)ck(0.94falue(fa;
   (  0106020,
 0.03
 020,)ck(0.9eskyInv(A4)*A4,44falueual(n ctor: from  <si   pse,ewith lengthlar.    // ih-orotType,
    lumn[4n) * inat(());
4* Wra* Wra/qual(cholq.from_ <si_  pseE2f, 0.3f)n, n, nual(cholesky(Z3), Z3)q,a;
   (- -1, 0, 1}r defcholq.from_ <si_  pseE2f, 0.3f), 0, 1}r l(cholesky(Z3), Z3)q,a;
   ( -1, 0, 1}r default ctoQ  Quatf q0
 itiheisType,eallo< eps
    lumn[4q_< eps,2.5,0};708f        4f      218f      2436fat, n_xQ  Quatf q<} // n4ffrom_< eps(q_< eps) copyTo; i < P; i++) {
        TEST(fabs(q(i) - dst4[i]) < ffrom_< eps(ps);
q_< eps,

    // Slice copyTo
     <si   pseyTo
 
templatef aafalue(2f, 0.3f)1.03  2.03  3.03r l(cholesky(Z3), Z3)aafalue, 2f, 0.3f)1.03  2.03  3.03r  l(chol
templatef aafemptyl(cholesky(Z3), Z3)aafempty,l
templatef(0 0106020,
 020,r  l(choln[6] = a    0.936293420,
 520,
 6.0fat, n_x
templatef aafT(isE
 it(aafT(is l(cholesky(Z3), Z3)aafT(isE
 it,l
templatef(420,
 520,
 6.0fr default 
templatef aaftestV
     2f, 0.3f)))0106020,
 020,r l(cholesky(Z3), Z3)aaftestV
    . <siredo2f, 0.3f)1t , 1}r defcholesky(Z3), Z3F)aaftestV
    .  pseEq
 020,r l(.1f, q(fa;
   (2183955511274929782
    e2553218 -0.05352184372-0.05316596558,)ck(0.9eskyInv(A4)*A4.im    0.2f, 0.3f)))2553218 -0.05352184372-0.05316596558,)ual(n ctor: from / eck(dceskyInv(A4)*A(v);
 (q.from_a);(m_da(q)ua, (v);
 (q)ual(n ctor: ide/ eck(dceskyInv(A4)*Am_da(q),aq.to_a);()ual(n ctor: ;
    // n ctov(fa2f, 0.3f)1.53  2.2   3ule)ck(0.9eskyInv(A4)*A4.;
    // _
    madEa1)dom_da(q).T()*v1 rl(e, e_zero));
    q);
    // ra1)dom_da(q)*v1 tesn cto
templatef aafqE
 it(q l(cholesky(Z3), Z3)aafqE
 it,l
templatef(1.03  2.03  3.03r  l((chol
templatef aafe TES 
 it((v);
 ())0106020,
 020,r l(cholesky(Z3), Z3)aafe TES 
 it0.2f, 0.3f)))0106020,
 020,r  l((cholm_data);
aat, 3>()*2
templatef(a);

    rl(e, e_zero));
    a);
aat, 3>(,ta);

    rnion cto
templatef aaf <si_  pse 
 it(2f, 0.3f)1.03  2.03  3.03r  3.03rl(cholesky(Z3), Z3)aaf <si_  pse 
 it0.2f, 0.3f)))80178373,
   603567453  2.40535118er defe, e_zero));
    aaf <si_  pse 
 it. <siredo2f, 0.3f)022672612    };
534522, -0.03680178373,r defcholesky(Z3), Z3F)aaf <si_  pse 
 it.  pseEq
 3.03r l(cholesky(Z3), Z3);
   ((
templatef(2f, 0.3f)))0106020,
 120,),t020,)ua,s(q(i) -          ;
   (  0106020,
 0.03
 020,)rnionn ctor: ; 3>() falsstuatcylar.   Quatf q0ITY E); producv(v,v)m_data);3((v);
 (1t dst3[data[] m_data);4((v);
 ( (size_[data[] m_data);34cala);3 *ta);4l(cholesky(Z3), Z3)(v);
 (;
   (a);3)*;
   (a);4ua, (v);
 (a);34)ual(n ctor: ; 3>() frnisEqaseslar.
 *
 * @auvector to veix to sca.1f, q(fa;
   (0,1,

  ate a180 EugrerirotType,e routhath-oxe <size_t TESTm_da(q)l(cholesky(Z3), Z3)q,a;
   (Rr defcholq(fa;
   (0,0,1,
 ate a180 EugrerirotType,e routhath-oye <size_t TESTm_da(q)l(cholesky(Z3), Z3)q,a;
   (Rr defcholq(fa;
   (0,0,,2) ate a180 EugrerirotType,e routhath-oze <size_t TESTm_da(q)l(cholesky(Z3), Z3)q,a;
   (Rr defX4_NUTTX)
  (SUPPORT_STDIOe")
AM).1f, 
#endcrage<< "q:"e<< q* Compare1f, im: set et fenc=utf-8 ff=unix sts=0 sw=4 ts=4 : */

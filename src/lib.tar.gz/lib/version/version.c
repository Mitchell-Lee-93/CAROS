/****************************************************************************
 *
 *   Copyright (c) 2016 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

#include "version.h"

#include "build_git_version.h"

#include <string.h>

#if !defined(CONFIG_CDCACM_PRODUCTID)
# define CONFIG_CDCACM_PRODUCTID 0
#endif

#if defined(__PX4_LINUX)
#include <sys/utsname.h>
#endif

// dev >= 0
// alpha >= 64
// beta >= 128
// release candidate >= 192
// release == 255
enum FIRMWARE_TYPE {
	FIRMWARE_TYPE_DEV = 0,
	FIRMWARE_TYPE_ALPHA = 64,
	FIRMWARE_TYPE_BETA = 128,
	FIRMWARE_TYPE_RC = 192,
	FIRMWARE_TYPE_RELEASE = 255
};

const char *px4_build_uri(void)
{
	return STRINGIFY(BUILD_URI);
}

uint32_t version_tag_to_number(const char *tag)
{
	uint32_t version_number = 0;

	int16_t buffer = -1;
	size_t buffer_counter = 0;
	size_t dash_count = 0;
	size_t point_count = 0;
	char version[3] = {0, 0, 0};
	int firmware_type = FIRMWARE_TYPE_RELEASE;

	for (size_t i = 0; i < strlen(tag); i++) {
		if (tag[i] == '-') {
			dash_count++;

		} else if (tag[i] == '.') {
			point_count++;
		}

		if (tag[i] == 'r' && i < strlen(tag) - 1 && tag[i + 1] == 'c') {
			firmware_type = FIRMWARE_TYPE_RC;

		} else if (tag[i] == 'p') {
			firmware_type = FIRMWARE_TYPE_ALPHA;

		} else if (tag[i] == 't' && i < strlen(tag) - 1 && tag[i + 1] == 'y') {
			firmware_type = FIRMWARE_TYPE_DEV;

		} else if (tag[i] == 't') {
			firmware_type = FIRMWARE_TYPE_BETA;

		} else if (tag[i] == 'v' && i > 0) {
			firmware_type = FIRMWARE_TYPE_DEV;
		}
	}

	if ((dash_count == 1 && point_count == 2 && firmware_type == FIRMWARE_TYPE_RELEASE) ||
	    (dash_count == 2 && point_count == 2) ||
	    (dash_count == 3 && point_count == 4) ||
	    (dash_count == 4 && point_count == 4)) {
		firmware_type = FIRMWARE_TYPE_DEV;
	}

	for (size_t i = 0; i < strlen(tag); i++) {
		if (buffer_counter > 2) {
			continue;
		}

		if (tag[i] >= '0' && tag[i] <= '9') {
			buffer = (buffer == -1) ? 0 : buffer;
			buffer = buffer * 10 + (tag[i] - '0');

		} else {
			if (buffer >= 0) {
				version[buffer_counter] = buffer;
				buffer_counter++;
			}

			buffer = -1;
		}
	}

	if (buffer >= 0) {
		version[buffer_counter] = buffer;
		buffer_counter++;
	}

	if (buffer_counter <= 0) {
		firmware_type = 0x00;
	}

	if (buffer_counter == 3 || buffer_counter == 6) {
		version_number = ((uint8_t)version[0] << 8 * 3) |
				 ((uint8_t)version[1] << 8 * 2) |
				 ((uint8_t)version[2] << 8 * 1) | firmware_type;

	} else {
		version_number = 0;
	}

	return version_number;
}

uint32_t px4_firmware_version(void)
{
	return version_tag_to_number(PX4_GIT_TAG_STR);
}

uint32_t version_tag_to_vendor_version_number(const char *tag)
{
	uint32_t version_number = 0;

	int16_t buffer = -1;
	size_t buffer_counter = 0;
	char version[6] = {0, 0, 0, 0, 0, 0};
	size_t dash_count = 0;
	size_t point_count = 0;
	int firmware_type = FIRMWARE_TYPE_RELEASE;

	for (size_t i = 0; i < strlen(tag); i++) {
		if (tag[i] == '-') {
			dash_count++;

		} else if (tag[i] == '.') {
			point_count++;
		}

		if (tag[i] == 'r' && i < strlen(tag) - 1 && tag[i + 1] == 'c') {
			firmware_type = FIRMWARE_TYPE_RC;

		} else if (tag[i] == 'p') {
			firmware_type = FIRMWARE_TYPE_ALPHA;

		} else if (tag[i] == 't' && i < strlen(tag) - 1 && tag[i + 1] == 'y') {
			firmware_type = FIRMWARE_TYPE_DEV;

		} else if (tag[i] == 't') {
			firmware_type = FIRMWARE_TYPE_BETA;

		} else if (tag[i] == 'v' && i > 0) {
			firmware_type = FIRMWARE_TYPE_DEV;
		}
	}

	if ((dash_count == 1 && point_count == 2 && firmware_type == FIRMWARE_TYPE_RELEASE) ||
	    (dash_count == 2 && point_count == 2) ||
	    (dash_count == 3 && point_count == 4) ||
	    (dash_count == 4 && point_count == 4)) {
		firmware_type = FIRMWARE_TYPE_DEV;
	}

	for (size_t i = 0; i < strlen(tag); i++) {
		if (buffer_counter > 5) {
			continue;
		}

		if (tag[i] >= '0' && tag[i] <= '9') {
			buffer = (buffer == -1) ? 0 : buffer;
			buffer = buffer * 10 + (tag[i] - '0');

		} else {
			if (buffer >= 0) {
				if (buffer_counter + 1 == 4 && tag[i] == '-') {
					break;
				}

				version[buffer_counter] = buffer;
				buffer_counter++;
			}

			buffer = -1;
		}
	}

	if (buffer >= 0 && (buffer_counter + 1 == 3 || buffer_counter + 1 == 6)) {
		version[buffer_counter] = buffer;
		buffer_counter++;
	}

	if (buffer_counter == 6) {
		version_number = ((uint8_t)version[3] << 8 * 3) |
				 ((uint8_t)version[4] << 8 * 2) |
				 ((uint8_t)version[5] << 8 * 1) | firmware_type;

	} else if (buffer_counter == 3) {
		version_number = firmware_type;

	} else {
		version_number = 0;
	}

	return version_number;
}

uint32_t px4_firmware_vendor_version(void)
{
	return version_tag_to_vendor_version_number(PX4_GIT_TAG_STR);
}

const char *px4_firmware_git_branch(void)
{
	return PX4_GIT_BRANCH_NAME;
}

uint32_t px4_board_version(void)
{
#if defined(__PX4_NUTTX)
	return CONFIG_CDCACM_PRODUCTID;
#else
	return 1;
#endif
}

uint32_t px4_os_version(void)
{
#if defined(__PX4_DARWIN) || defined(__PX4_CYGWIN) || defined(__PX4_QURT)
	return 0; //TODO: implement version for Darwin, Cygwin, QuRT
#elif defined(__PX4_LINUX)
	struct utsname name;

	if (uname(&name) == 0) {
		char *c = name.release;

		// cut the part after the firt_b afnter + 1hile ( nabuf na!') {
					br++c}

		if ( name}

	urn version_tag_to_number(PX4_.release;

	)} else {
		versrn 0; //T
	retf defined(__PX4_LINUX)
	return CONFion_tag_to_number(PX4_X)
	r_TAG_STR);
}

ce
	ret# errarw"os_version(voiice,lement verrom arwcurrversOS"dif
}

uintt char *px4_firmersion(voi_ng.h>
d)
{
#if defined(__PX4_NUTTX)
	return CONFX)
	r_TAG_VERSION);
}lse
	return 1;
#NULL;dif
}

uintt char *px4_firmers(&nam)
{
#if defined(__PX4_DARWIN) || turn 1;
#"in, Cy";if defined(__PX4_LINUX)
	strurn 1;
#"L;
	x";if defined(__PX4_LINU)
	return 0; /"
#el";if defined(__PX4_LINUX)
	return CONF"NuttX";if defined(__PX4_LINUIN) || turn CONF"in, Qu"
ce
	ret# errarw"os_vers name;e,lement verrom arwcurrversOS"dif
}

uintt char *px4_firmtool *pins(&nam)
{
#if defined(__PX4_clang__ turn CONF"ilang/LLVM";if defined(__PX4_ICC defined(__PX4_RRUPL_COMPILER turn CONF"Ierrl ICC";if defined(__PX4_GNUC__ defined(__PX4_GNUG__ turn CONF"GNU GCC";if defined(__PX4MSC_VER turn CONF"MS Visual Studio"lse
	return 1;
#"Unknowu"
ce

}

uintt char *px4_firmtool *pinsion(void)
{
#if defned __VERSION)_turn 1;
#__VERSION)_lse
	return 1;
#""
ce

}

uintt char *px4_firmware_version(voi_ng.h>
d)
{
#if urn PX4_GIT_BRANVERSION);
}lsint32_t timefirmware_version(voi_ry ford)
{
#if urn PX4_GIT_BRANVERSION)BINARY
const char *px4_firmecl_libsion(voi_ng.h>
d)
{
#if defned ECLUX)B_BRANVERSION);
}ING urn PX4_ECLUX)B_BRANVERSION);
}INGlse
	return 1;
#NULL;dif
}

uintdefned MAVX)
KUX)B_BRANVERSION)BINARYt32_t timefirmmavlink_libsion(voi_ry ford)
{
#if urn PX4_MAVX)
KUX)B_BRANVERSION)BINARY
conif
}

 /*_MAVX)
KUX)B_BRANVERSION)BINARY #inc32_t timefirmersion(voi_ry ford)
{
#if defned X)
	r_TAG_VERSION)BINARYturn CONFX)
	r_TAG_VERSION)BINARY
ce
	return 1;
#0;dif
}

